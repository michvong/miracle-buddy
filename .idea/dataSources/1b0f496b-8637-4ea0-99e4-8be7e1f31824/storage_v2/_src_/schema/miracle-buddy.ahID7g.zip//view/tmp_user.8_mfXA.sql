create definer = root@localhost view tmp_user as
select `miracle-buddy`.`regularuser`.`user_id`  AS `user_id`,
       `miracle-buddy`.`regularuser`.`name`     AS `name`,
       `miracle-buddy`.`regularuser`.`language` AS `language`,
       `miracle-buddy`.`regularuser`.`email`    AS `email`
from `miracle-buddy`.`regularuser`
where `miracle-buddy`.`regularuser`.`user_id` = 1;

