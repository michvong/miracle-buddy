create definer = root@localhost view tmp_inventory as
select avg(`miracle-buddy`.`inventory`.`stock`) AS `AVG(stock)`
from `miracle-buddy`.`inventory`
group by `miracle-buddy`.`inventory`.`warehouse_id`;

